<doctype! html>
<html>
<body>

<?php
// google php login to see secure ways to do it 
?>

</body>
</html>
