<doctype! html>
<html>
<body>

<?php
$full_name=$_POST["full_name"];
$age=$_POST["age"];
$email=$_POST["email"];
echo "Welcome, $full_name.<br> We've been expecting you.<br>";
echo "We know you're $age, and your email address: $email.<br>";
?>

</body>
</html>
